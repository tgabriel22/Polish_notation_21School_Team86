#include "calculate.h"

// Обработка числа в постфиксной записи
// postfix - строка с выражением
// i - указатель на текущую позицию в строке
static double handle_number(char *postfix, int *i) {
    // Преобразуем подстроку в число
    double num = atof(postfix + *i);
    // Пропускаем все цифры и десятичную точку
    while (postfix[*i] && (isdigit(postfix[*i + 1]) || postfix[*i + 1] == '.')) {
        (*i)++;
    }
    return num;
}

// Обработка оператора
// op - оператор
// stack - стек для вычислений
// top - указатель на вершину стека
// valid - флаг валидности выражения
static void process_operator(char op, double *stack, int *top, int *valid) {
    // Извлекаем операнды из стека
    double a = stack[(*top)--];
    double b = 0;
    double result = NAN;

    // Для бинарных операторов извлекаем второй операнд
    if (!strchr("sctgql~", op)) {
        b = stack[(*top)--];
    }

    // Выполняем операцию и кладем результат обратно в стек
    result = perform_operation(a, b, op, valid);
    stack[++(*top)] = result;
}

// Выполнение математической операции
// a, b - операнды
// op - оператор
// valid - флаг валидности
double perform_operation(double a, double b, char op, int *valid) {
    double result = NAN;
    switch (op) {
        case '+':
            result = b + a;  // Сложение
            break;
        case '-':
            result = b - a;  // Вычитание
            break;
        case '*':
            result = b * a;  // Умножение
            break;
        case '/':
            result = b / a;  // Деление
            break;
        case 's':
            result = sin(a);  // Синус
            break;
        case 'c':
            result = cos(a);  // Косинус
            break;
        case 't':
            result = tan(a);  // Тангенс
            break;
        case 'g':
            result = 1.0 / tan(a);  // Котангенс
            break;
        case 'q':
            result = sqrt(a);  // Квадратный корень
            break;
        case 'l':
            result = log(a);  // Натуральный логарифм
            break;
        case '~':
            result = -a;  // Унарный минус
            break;
        default:
            *valid = 0;  // Неизвестный оператор
            result = NAN;
    }
    return result;
}

// Основная функция вычисления постфиксного выражения
// postfix - строка с постфиксным выражением
// x - значение переменной x
// valid - флаг валидности выражения
double calculate(char *postfix, double x, int *valid) {
    double stack[256];    // Стек для вычислений
    int top = -1;         // Индекс вершины стека
    double result = NAN;  // Результат вычислений

    // Обрабатываем каждый символ выражения
    for (int i = 0; postfix[i] && *valid; i++) {
        if (postfix[i] == 'x') {
            // Если переменная x, кладем ее значение в стек
            stack[++top] = x;
        } else if (isdigit(postfix[i]) || postfix[i] == '.') {
            // Если число, обрабатываем и кладем в стек
            stack[++top] = handle_number(postfix, &i);
        } else if (postfix[i] != ' ') {
            // Если оператор, обрабатываем
            process_operator(postfix[i], stack, &top, valid);
        }
    }

    // Возвращаем результат с вершины стека или NAN при ошибке
    if (*valid) {
        result = stack[top];
    } else {
        result = NAN;
    }

    return result;
}