#include "parse.h"

/* Определение приоритета операторов */
static int precedence(char op) {
    int result = 0;
    if (op == '+' || op == '-')  // Низкий приоритет для + и -
        result = 1;
    else if (op == '*' || op == '/')  // Средний приоритет для * и /
        result = 2;
    else if (strchr("sctgql~", op))  // Высокий приоритет для функций и унарного минуса
        result = 3;
    return result;
}

/* Проверка, является ли подстрока математической функцией */
static int is_function(const char *s, int i) {
    int result = 0;
    if (!strncmp(s + i, "sin", 3))  // Проверка на sin
        result = SIN;
    else if (!strncmp(s + i, "cos", 3))  // Проверка на cos
        result = COS;
    else if (!strncmp(s + i, "tan", 3))  // Проверка на tan
        result = TAN;
    else if (!strncmp(s + i, "ctg", 3))  // Проверка на ctg
        result = CTG;
    else if (!strncmp(s + i, "sqrt", 4))  // Проверка на sqrt
        result = SQRT;
    else if (!strncmp(s + i, "ln", 2))  // Проверка на ln
        result = LN;
    else if (s[i] == '~')  // Проверка на унарный минус
        result = UMINUS;
    return result;
}

/* Валидация операторов (преобразование унарного минуса) */
void validate_operators(char *expr) {
    for (int i = 0; expr[i]; i++) {
        // Если минус в начале или после открывающей скобки - это унарный минус
        if (expr[i] == '-' && (i == 0 || expr[i - 1] == '(')) {
            expr[i] = UMINUS;  // Заменяем на специальный символ
        }
    }
}

/* Ввод выражения от пользователя */
char *input_expression(int *valid) {
    char *input = NULL;
    if (*valid) {
        input = malloc(256);  // Выделяем память для строки
        if (input) {
            int i = 0;
            char c;
            // Читаем символы до конца строки или заполнения буфера
            while ((c = getchar()) != '\n' && i < 255) {
                if (c != ' ') input[i++] = c;  // Пропускаем пробелы
            }
            input[i] = '\0';            // Завершаем строку
            validate_operators(input);  // Проверяем операторы
        } else {
            *valid = 0;  // Ошибка выделения памяти
        }
    }
    return input;
}

/* Обработка чисел в выражении */
void process_number(char *infix, int *i, char *postfix, int *j) {
    postfix[(*j)++] = infix[(*i)++];  // Записываем первую цифру
    // Продолжаем записывать цифры и точку
    while (isdigit(infix[*i]) || infix[*i] == '.') {
        postfix[(*j)++] = infix[(*i)++];
    }
    postfix[(*j)++] = ' ';  // Добавляем пробел после числа
}

/* Обработка скобок в выражении */
void process_parentheses(const char *infix, int *i, char *stack, int *top, char *postfix, int *j,
                         int *valid) {
    if (infix[*i] == '(') {
        stack[++(*top)] = '(';  // Открывающую скобку в стек
        (*i)++;
    } else {
        // Выталкиваем операторы из стека пока не найдем открывающую скобку
        while (*top != -1 && stack[*top] != '(') {
            postfix[(*j)++] = stack[(*top)--];
            postfix[(*j)++] = ' ';
        }
        if (*top == -1)
            *valid = 0;  // Несбалансированные скобки
        else
            (*top)--;  // Удаляем открывающую скобку
        (*i)++;
    }
}

/* Обработка операторов */
void process_operator(char op, char *stack, int *top, char *postfix, int *j) {
    // Выталкиваем операторы с большим или равным приоритетом
    while (*top != -1 && precedence(stack[*top]) >= precedence(op)) {
        postfix[(*j)++] = stack[(*top)--];
        postfix[(*j)++] = ' ';
    }
    stack[++(*top)] = op;  // Кладем оператор в стек
}

/* Преобразование инфиксной записи в постфиксную (ОПН) */
char *to_postfix(char *infix, int *valid) {
    char *postfix = malloc(512);  // Выделяем память для результата
    char stack[256] = {0};        // Стек для операторов
    int top = -1, j = 0, i = 0;   // Индексы для стека и строк

    while (infix[i] && *valid) {
        if (infix[i] == 'x' || isdigit(infix[i]) || infix[i] == '.') {
            process_number(infix, &i, postfix, &j);  // Обработка чисел
        } else if (infix[i] == '(' || infix[i] == ')') {
            process_parentheses(infix, &i, stack, &top, postfix, &j, valid);  // Скобки
        } else {
            int func = is_function(infix, i);  // Проверяем функции
            if (func) {
                process_operator(func, stack, &top, postfix, &j);  // Обработка функций
                i += (func == SQRT) ? 4 : (func == LN) ? 2 : 3;    // Сдвигаем индекс
            } else if (strchr("+-*/", infix[i])) {
                process_operator(infix[i], stack, &top, postfix, &j);  // Операторы
                i++;
            } else {
                *valid = 0;  // Недопустимый символ
            }
        }
    }

    // Выталкиваем оставшиеся операторы из стека
    while (top != -1 && *valid) {
        if (stack[top] == '(') *valid = 0;  // Несбалансированные скобки
        postfix[j++] = stack[top--];
        postfix[j++] = ' ';
    }
    postfix[j] = '\0';  // Завершаем строку
    return postfix;
}